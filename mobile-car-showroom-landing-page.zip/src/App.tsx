import { useEffect } from "react";
import { ScrollTrigger } from "./lib/gsap";
import Nav from "./components/Nav";
import Hero from "./components/Hero";
import TextReveal from "./components/TextReveal";
import StoryChapters from "./components/StoryChapters";
import Collection from "./components/Collection";
import Services from "./components/Services";
import Testimonial from "./components/Testimonial";
import Visit from "./components/Visit";
import Footer from "./components/Footer";
import StickyCTA from "./components/StickyCTA";
import Reveal from "./components/Reveal";

const manifesto =
  "We are a family business, not a forecourt. Since 1998 we've kept the collection deliberately small, so every car is known, prepared and stood behind by the people who sold it to you. If a car isn't right, it doesn't come here.";

const stats = [
  ["1998", "Established"],
  ["24", "Cars in stock"],
  ["4.9", "Google rating"],
];

export default function App() {
  // Re-measure pin/scrub positions once fonts and images have settled
  useEffect(() => {
    const refresh = () => {
      ScrollTrigger.sort();
      ScrollTrigger.refresh();
    };
    window.addEventListener("load", refresh);
    document.fonts?.ready.then(refresh);
    return () => window.removeEventListener("load", refresh);
  }, []);

  return (
    <div className="page">
      <Nav />

      <main>
        <Hero />

        {/* Manifesto — 21st.dev Text Reveal */}
        <TextReveal
          className="bg-ink"
          eyebrow={<p className="eyebrow text-brass">Welcome to Marlowe</p>}
          footer={
            <div className="grid grid-cols-3 border-t border-bone/10 pt-6">
              {stats.map(([n, l]) => (
                <div key={l}>
                  <p className="num display text-[1.75rem] leading-none text-bone">{n}</p>
                  <p className="eyebrow mt-2 text-bone/40">{l}</p>
                </div>
              ))}
            </div>
          }
        >
          {manifesto}
        </TextReveal>

        {/* Story */}
        <Reveal className="bg-ink px-6 pt-6 pb-12">
          <p className="eyebrow text-brass">Chapter by chapter</p>
          <h2 className="display mt-4 text-[2.6rem] text-bone">How a car reaches you.</h2>
          <p className="mt-4 max-w-[34ch] font-sans text-[14.5px] leading-[1.65] text-bone/60">
            The same three steps, for a £40,000 classic or a £400,000 supercar. Keep scrolling.
          </p>
        </Reveal>
        <StoryChapters />

        <Collection />
        <Services />
        <Testimonial />
        <Visit />
      </main>

      <Footer />
      <StickyCTA />
    </div>
  );
}
