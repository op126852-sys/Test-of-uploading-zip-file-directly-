import { useRef, useState } from "react";
import { ArrowRight } from "lucide-react";
import { gsap, useGSAP } from "../lib/gsap";
import { collection, formatMiles, formatPrice, type Car } from "../data/content";
import Reveal from "./Reveal";
import { cn } from "../utils/cn";

export default function Collection() {
  const root = useRef<HTMLElement>(null);
  const scroller = useRef<HTMLDivElement>(null);
  const [progress, setProgress] = useState(0);

  useGSAP(
    () => {
      gsap.from(".car-card", {
        y: 36,
        autoAlpha: 0,
        duration: 1.1,
        stagger: 0.12,
        ease: "power3.out",
        scrollTrigger: { trigger: scroller.current, start: "top 85%", once: true },
      });
    },
    { scope: root }
  );

  const onScroll = () => {
    const el = scroller.current;
    if (!el) return;
    const max = el.scrollWidth - el.clientWidth;
    setProgress(max > 0 ? el.scrollLeft / max : 0);
  };

  return (
    <section id="collection" ref={root} className="bg-ink pt-24 pb-20" aria-label="The collection">
      <Reveal className="flex items-end justify-between px-6">
        <div>
          <p className="eyebrow text-brass">The collection</p>
          <h2 className="display mt-4 text-[2.6rem] text-bone">In the showroom now.</h2>
        </div>
        <a
          href="#collection"
          className="tap mb-2 flex shrink-0 items-center gap-1.5 eyebrow text-bone/60"
        >
          All 24
          <ArrowRight className="h-3.5 w-3.5" strokeWidth={1.5} />
        </a>
      </Reveal>

      <div
        ref={scroller}
        onScroll={onScroll}
        className="no-scrollbar mt-10 flex snap-x snap-mandatory gap-4 overflow-x-auto scroll-px-6 px-6 pb-2"
      >
        {collection.map((car) => (
          <CarCard key={car.id} car={car} />
        ))}

        {/* Trailing card */}
        <a
          href="#collection"
          className="car-card tap flex w-[58vw] max-w-[260px] shrink-0 snap-start flex-col justify-between border border-bone/10 p-6"
        >
          <p className="eyebrow text-bone/50">Full stock list</p>
          <div>
            <p className="display text-[2.2rem] leading-none text-bone">
              24 <span className="text-[1.1rem] italic font-light text-bone/60">cars</span>
            </p>
            <p className="mt-3 font-sans text-[13px] leading-relaxed text-bone/55">
              Updated daily. New arrivals are photographed within the week.
            </p>
            <span className="mt-6 flex h-10 w-10 items-center justify-center rounded-full border border-bone/25 text-bone">
              <ArrowRight className="h-4 w-4" strokeWidth={1.5} />
            </span>
          </div>
        </a>
      </div>

      {/* Scroll position */}
      <div className="mx-6 mt-6 h-px bg-bone/10">
        <div
          className="h-full bg-bone/70 transition-[width] duration-150 ease-out"
          style={{ width: `${Math.max(12, progress * 100)}%` }}
        />
      </div>

      <div className="mt-8 px-6">
        <p className="font-sans text-[12.5px] leading-relaxed text-bone/45">
          Every car is sold with a full provenance check, fresh service and a minimum six-month
          warranty. Prices include VAT where applicable.
        </p>
      </div>
    </section>
  );
}

function CarCard({ car }: { car: Car }) {
  return (
    <article className="car-card w-[78vw] max-w-[340px] shrink-0 snap-start">
      <div className="relative aspect-[4/3] overflow-hidden bg-ink-2">
        <img
          className="h-full w-full object-cover"
          src={car.image}
          alt={`${car.year} ${car.make} ${car.model} in ${car.colour}`}
          loading="lazy"
          decoding="async"
        />
        {car.status && (
          <span
            className={cn(
              "eyebrow absolute left-3 top-3 px-2.5 py-2 backdrop-blur-md",
              car.status === "Reserved"
                ? "bg-ink/70 text-bone/70"
                : "bg-bone/90 text-ink"
            )}
          >
            {car.status}
          </span>
        )}
      </div>

      <div className="mt-4">
        <p className="eyebrow text-bone/45">
          <span className="num">{car.year}</span>
          <span className="mx-2 text-bone/25">·</span>
          {car.colour}
        </p>
        <h3 className="display mt-2 text-[1.65rem] leading-[1.05] text-bone">
          {car.make} {car.model}
        </h3>
        {car.variant && (
          <p className="mt-1.5 font-sans text-[12.5px] text-bone/50">{car.variant}</p>
        )}
      </div>

      <div className="mt-4 flex items-baseline justify-between border-t border-bone/10 pt-4">
        <p className="num font-sans text-[15px] font-medium text-bone">{formatPrice(car.price)}</p>
        <p className="num font-sans text-[12px] text-bone/50">
          {formatMiles(car.miles)} · {car.gearbox}
        </p>
      </div>
    </article>
  );
}
