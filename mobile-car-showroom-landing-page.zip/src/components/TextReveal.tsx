import { useRef, type ReactNode } from "react";
import { gsap, useGSAP } from "../lib/gsap";
import { cn } from "../utils/cn";

/**
 * Text Reveal — from 21st.dev (Magic UI / @dillionverma).
 * A 200vh track with a sticky viewport; each word sits over a faint ghost copy
 * and fades to full ink as scroll progress crosses its slice of the range.
 * Ported to GSAP ScrollTrigger (scrub) so it shares the page's animation engine.
 */
interface TextRevealProps {
  children: string;
  className?: string;
  eyebrow?: ReactNode;
  footer?: ReactNode;
}

export function TextReveal({ children, className, eyebrow, footer }: TextRevealProps) {
  const targetRef = useRef<HTMLDivElement>(null);
  const words = children.split(" ");

  useGSAP(
    () => {
      // Sequential, non-overlapping windows — identical to the original's
      // per-word [i / n, (i + 1) / n] opacity ranges.
      gsap.fromTo(
        ".tr-word",
        { opacity: 0 },
        {
          opacity: 1,
          ease: "none",
          duration: 1,
          stagger: 1,
          scrollTrigger: {
            trigger: targetRef.current,
            start: "top 35%",
            end: "bottom bottom",
            scrub: true,
          },
        }
      );

      gsap.from(".tr-footer", {
        autoAlpha: 0,
        y: 16,
        duration: 0.9,
        scrollTrigger: {
          trigger: targetRef.current,
          start: "bottom 92%",
          toggleActions: "play none none reverse",
        },
      });
    },
    { scope: targetRef }
  );

  return (
    <div ref={targetRef} className={cn("relative z-0 h-[200vh]", className)}>
      <div className="sticky top-0 mx-auto flex h-[50%] max-w-4xl flex-col justify-center px-6 py-16">
        {eyebrow && <div className="mb-6">{eyebrow}</div>}
        <span className="display flex flex-wrap text-[clamp(1.6rem,8vw,1.95rem)] leading-[1.2] text-bone/15">
          {words.map((word, i) => (
            <span key={i} className="relative mr-[0.28em]">
              <span className="absolute opacity-30">{word}</span>
              <span className="tr-word text-bone">{word}</span>
            </span>
          ))}
        </span>
        {footer && <div className="tr-footer mt-8">{footer}</div>}
      </div>
    </div>
  );
}

export default TextReveal;
