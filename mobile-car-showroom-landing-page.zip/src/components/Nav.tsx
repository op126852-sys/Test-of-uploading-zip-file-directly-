import { useRef, useState } from "react";
import { Phone, ArrowUpRight } from "lucide-react";
import { gsap, useGSAP, ScrollTrigger } from "../lib/gsap";
import { showroom } from "../data/content";
import { cn } from "../utils/cn";

const links = [
  { label: "Collection", href: "#collection" },
  { label: "Our story", href: "#story" },
  { label: "Sell your car", href: "#services" },
  { label: "Visit", href: "#visit" },
];

export default function Nav() {
  const bar = useRef<HTMLElement>(null);
  const overlay = useRef<HTMLDivElement>(null);
  const [open, setOpen] = useState(false);
  const [solid, setSolid] = useState(false);

  // Bar becomes solid once the hero has scrolled away
  useGSAP(() => {
    ScrollTrigger.create({
      start: 80,
      end: "max",
      onToggle: (self) => setSolid(self.isActive),
    });
  });

  // Menu open / close — context-safe via useGSAP's contextSafe
  const { contextSafe } = useGSAP({ scope: overlay });

  const openMenu = contextSafe(() => {
    setOpen(true);
    document.documentElement.style.overflow = "hidden";
    const tl = gsap.timeline();
    tl.set(overlay.current, { autoAlpha: 1 })
      .fromTo(
        overlay.current,
        { clipPath: "inset(0 0 100% 0)" },
        { clipPath: "inset(0 0 0% 0)", duration: 0.7, ease: "power4.inOut" }
      )
      .fromTo(
        ".menu-link",
        { yPercent: 110 },
        { yPercent: 0, duration: 0.8, stagger: 0.06, ease: "power3.out" },
        "-=0.3"
      )
      .fromTo(
        ".menu-meta",
        { y: 16, autoAlpha: 0 },
        { y: 0, autoAlpha: 1, duration: 0.6, stagger: 0.08 },
        "-=0.5"
      );
  });

  const closeMenu = contextSafe(() => {
    const tl = gsap.timeline({
      onComplete: () => {
        setOpen(false);
        document.documentElement.style.overflow = "";
      },
    });
    tl.to(".menu-link", { yPercent: -110, duration: 0.4, stagger: 0.03, ease: "power2.in" })
      .to(".menu-meta", { autoAlpha: 0, duration: 0.25 }, 0)
      .to(
        overlay.current,
        { clipPath: "inset(0 0 100% 0)", duration: 0.55, ease: "power4.inOut" },
        "-=0.15"
      )
      .set(overlay.current, { autoAlpha: 0 });
  });

  return (
    <>
      <header
        ref={bar}
        className={cn(
          "fixed-col top-0 z-50 safe-top transition-colors duration-500",
          solid && !open ? "bg-ink/85 backdrop-blur-md" : "bg-transparent"
        )}
      >
        <div className="flex h-14 items-center justify-between px-5">
          <a
            href="#top"
            className="tap font-sans text-[13px] font-semibold uppercase tracking-[0.28em] text-bone"
            aria-label="Marlowe Motor Company — home"
          >
            Marlowe
          </a>

          <div className="flex items-center gap-1">
            <a
              href={showroom.phoneHref}
              className="tap flex h-11 w-11 items-center justify-center rounded-full text-bone/80 active:bg-bone/10"
              aria-label={`Call ${showroom.phone}`}
            >
              <Phone className="h-[18px] w-[18px]" strokeWidth={1.5} />
            </a>
            <button
              type="button"
              onClick={open ? closeMenu : openMenu}
              className="tap -mr-2 flex h-11 items-center gap-2 px-2 font-sans text-[11px] font-medium uppercase tracking-[0.22em] text-bone"
              aria-expanded={open}
              aria-controls="site-menu"
            >
              <span className="relative z-[60]">{open ? "Close" : "Menu"}</span>
              <span className="relative z-[60] flex h-3 w-5 flex-col justify-between" aria-hidden>
                <span
                  className={cn(
                    "block h-px w-full bg-bone transition-transform duration-300 origin-center",
                    open && "translate-y-[5.5px] rotate-45"
                  )}
                />
                <span
                  className={cn(
                    "block h-px w-full bg-bone transition-opacity duration-200",
                    open && "opacity-0"
                  )}
                />
                <span
                  className={cn(
                    "block h-px w-full bg-bone transition-transform duration-300 origin-center",
                    open && "-translate-y-[5.5px] -rotate-45"
                  )}
                />
              </span>
            </button>
          </div>
        </div>
      </header>

      {/* Full-screen menu */}
      <div
        id="site-menu"
        ref={overlay}
        className="fixed-col inset-y-0 z-[45] invisible flex h-[100dvh] flex-col justify-between bg-ink px-6 pt-24 pb-10 safe-bottom"
        style={{ clipPath: "inset(0 0 100% 0)" }}
        aria-hidden={!open}
      >
        <nav>
          <ul className="space-y-1">
            {links.map((l, i) => (
              <li key={l.href} className="overflow-hidden">
                <a
                  href={l.href}
                  onClick={closeMenu}
                  className="menu-link tap group flex items-baseline justify-between py-2 will-change-transform"
                >
                  <span className="display text-[2.75rem] leading-[1.1] text-bone">{l.label}</span>
                  <span className="num font-sans text-[11px] tracking-[0.2em] text-bone/40">
                    0{i + 1}
                  </span>
                </a>
              </li>
            ))}
          </ul>
        </nav>

        <div className="space-y-6">
          <div className="menu-meta hairline" />
          <div className="menu-meta grid grid-cols-2 gap-6 font-sans text-[13px] leading-relaxed text-bone/70">
            <div>
              <p className="eyebrow mb-3 text-bone/40">Showroom</p>
              {showroom.address.map((line) => (
                <p key={line}>{line}</p>
              ))}
            </div>
            <div>
              <p className="eyebrow mb-3 text-bone/40">Contact</p>
              <a href={showroom.phoneHref} className="block">
                {showroom.phone}
              </a>
              <a href={`mailto:${showroom.email}`} className="block break-all">
                {showroom.email}
              </a>
            </div>
          </div>
          <a
            href="#visit"
            onClick={closeMenu}
            className="menu-meta tap flex h-13 items-center justify-between rounded-full bg-bone px-6 font-sans text-[12px] font-semibold uppercase tracking-[0.2em] text-ink"
          >
            Book a private viewing
            <ArrowUpRight className="h-4 w-4" strokeWidth={1.75} />
          </a>
        </div>
      </div>
    </>
  );
}
