import { useRef } from "react";
import { Phone } from "lucide-react";
import { gsap, useGSAP, ScrollTrigger } from "../lib/gsap";
import { showroom } from "../data/content";

/** Mobile bottom action bar — appears once the hero story has played out. */
export default function StickyCTA() {
  const root = useRef<HTMLDivElement>(null);

  useGSAP(
    () => {
      const bar = root.current!.firstElementChild as HTMLElement;
      gsap.set(bar, { yPercent: 140, autoAlpha: 0 });

      ScrollTrigger.create({
        start: () => window.innerHeight * 1.9,
        end: "max",
        onToggle: (self) =>
          gsap.to(bar, {
            yPercent: self.isActive ? 0 : 140,
            autoAlpha: self.isActive ? 1 : 0,
            duration: 0.6,
            ease: "power3.out",
            overwrite: true,
          }),
      });
    },
    { scope: root }
  );

  return (
    <div ref={root} className="fixed-col bottom-0 z-40 pointer-events-none safe-bottom">
      <div className="pointer-events-auto mx-4 mb-4 flex items-center gap-1.5 rounded-full border border-bone/10 bg-ink-2/90 p-1.5 shadow-[0_12px_40px_rgba(0,0,0,0.55)] backdrop-blur-xl">
        <a
          href={showroom.phoneHref}
          className="tap flex h-11 items-center gap-2 rounded-full px-4 font-sans text-[11px] font-medium uppercase tracking-[0.18em] text-bone active:bg-bone/10"
        >
          <Phone className="h-4 w-4" strokeWidth={1.5} />
          Call
        </a>
        <a
          href="#visit"
          className="tap flex h-11 flex-1 items-center justify-center rounded-full bg-bone font-sans text-[11px] font-semibold uppercase tracking-[0.18em] text-ink"
        >
          Book a viewing
        </a>
      </div>
    </div>
  );
}
