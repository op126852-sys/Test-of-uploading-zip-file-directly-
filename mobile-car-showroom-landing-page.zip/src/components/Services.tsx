import { ArrowUpRight } from "lucide-react";
import { services } from "../data/content";
import Reveal from "./Reveal";

export default function Services() {
  return (
    <section id="services" className="bg-ink px-6 pt-6 pb-24" aria-label="Services">
      <Reveal>
        <p className="eyebrow text-brass">Beyond the showroom</p>
        <h2 className="display mt-4 text-[2.6rem] text-bone">
          Whatever the next <span className="italic font-light">move</span> is.
        </h2>
      </Reveal>

      <Reveal stagger={0.08} className="mt-10 border-t border-bone/10">
        {services.map((s, i) => (
          <a
            key={s.title}
            href="#visit"
            className="tap group flex items-start justify-between gap-6 border-b border-bone/10 py-6"
          >
            <div className="flex gap-5">
              <span className="num mt-[3px] font-sans text-[11px] tracking-[0.2em] text-bone/35">
                0{i + 1}
              </span>
              <div>
                <h3 className="font-sans text-[17px] font-medium tracking-[-0.01em] text-bone">
                  {s.title}
                </h3>
                <p className="mt-1.5 max-w-[30ch] font-sans text-[13.5px] leading-[1.6] text-bone/55">
                  {s.body}
                </p>
              </div>
            </div>
            <ArrowUpRight
              className="mt-1 h-[18px] w-[18px] shrink-0 text-bone/40 transition-colors group-active:text-bone"
              strokeWidth={1.5}
            />
          </a>
        ))}
      </Reveal>
    </section>
  );
}
