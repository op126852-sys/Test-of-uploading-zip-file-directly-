import { useEffect, useRef, useState } from "react";
import { gsap, useGSAP } from "../lib/gsap";
import { chapters } from "../data/content";
import { cn } from "../utils/cn";

/**
 * Sticky Scroll Reveal — from 21st.dev (Aceternity UI), adapted for mobile.
 * The original keeps a sticky visual beside scrolling copy and swaps the visual
 * as the active block changes. On a phone there is no "beside", so the section
 * is pinned and a labelled, scrubbed GSAP timeline wipes each chapter through.
 */

function usePrefersReducedMotion() {
  const [reduced, setReduced] = useState(false);
  useEffect(() => {
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    setReduced(mq.matches);
    const onChange = (e: MediaQueryListEvent) => setReduced(e.matches);
    mq.addEventListener("change", onChange);
    return () => mq.removeEventListener("change", onChange);
  }, []);
  return reduced;
}

export default function StoryChapters() {
  const reduced = usePrefersReducedMotion();
  if (reduced) return <StaticChapters />;
  return <PinnedChapters />;
}

function PinnedChapters() {
  const root = useRef<HTMLElement>(null);
  const [active, setActive] = useState(0);
  const activeRef = useRef(0);

  useGSAP(
    () => {
      const imgs = gsap.utils.toArray<HTMLElement>(".ch-img");
      const pics = gsap.utils.toArray<HTMLElement>(".ch-pic");
      const txts = gsap.utils.toArray<HTMLElement>(".ch-txt");
      const n = chapters.length;

      gsap.set(imgs.slice(1), { clipPath: "inset(100% 0 0 0)" });
      gsap.set(txts.slice(1), { autoAlpha: 0, y: 28 });

      const tl = gsap.timeline({
        scrollTrigger: {
          trigger: root.current,
          start: "top top",
          end: () => "+=" + window.innerHeight * (n + 0.6),
          pin: true,
          scrub: 0.8,
          anticipatePin: 1,
          snap: {
            snapTo: "labelsDirectional",
            duration: { min: 0.15, max: 0.45 },
            delay: 0.05,
            ease: "power1.inOut",
          },
        },
        onUpdate() {
          const t = tl.time();
          let idx = 0;
          for (let i = 0; i < n; i++) if (tl.labels[`c${i}`] <= t + 0.001) idx = i;
          if (idx !== activeRef.current) {
            activeRef.current = idx;
            setActive(idx);
          }
        },
      });

      tl.addLabel("c0");
      // Slow push-in on the opening frame
      tl.fromTo(pics[0], { scale: 1.1 }, { scale: 1, duration: 1.2, ease: "none" }, 0);

      for (let i = 1; i < n; i++) {
        const at = `c${i - 1}+=1`;
        tl.to(txts[i - 1], { autoAlpha: 0, y: -22, duration: 0.4, ease: "none" }, at)
          .to(imgs[i], { clipPath: "inset(0% 0 0 0)", duration: 0.9, ease: "power1.inOut" }, at)
          .fromTo(pics[i], { scale: 1.14 }, { scale: 1, duration: 1.5, ease: "none" }, at)
          .fromTo(
            txts[i],
            { autoAlpha: 0, y: 28 },
            { autoAlpha: 1, y: 0, duration: 0.5, ease: "none" },
            `${at}+=0.55`
          )
          .addLabel(`c${i}`, `${at}+=1.05`);
      }
      // Dwell on the last chapter before the section releases
      tl.to({}, { duration: 1 });

      // Progress hairline across the whole story
      tl.to(".ch-bar", { scaleX: 1, duration: tl.duration(), ease: "none" }, 0);
    },
    { scope: root }
  );

  return (
    <section
      id="story"
      ref={root}
      className="relative h-[100svh] min-h-[600px] overflow-hidden bg-ink"
      aria-label="How a car reaches you"
    >
      {/* Visual stack */}
      <div className="absolute inset-x-0 top-0 h-[62%]">
        {chapters.map((c, i) => (
          <div
            key={c.n}
            className="ch-img absolute inset-0 overflow-hidden will-change-[clip-path]"
            style={{ zIndex: i }}
          >
            <img
              className="ch-pic h-full w-full object-cover will-change-transform"
              src={c.image}
              alt={c.alt}
              loading={i === 0 ? "eager" : "lazy"}
              decoding="async"
            />
          </div>
        ))}
        <div className="pointer-events-none absolute inset-x-0 top-0 z-10 h-32 bg-gradient-to-b from-ink/70 to-transparent" />
        <div className="pointer-events-none absolute inset-x-0 bottom-0 z-10 h-44 bg-gradient-to-t from-ink via-ink/75 to-transparent" />
      </div>

      {/* Header row */}
      <div className="absolute inset-x-0 top-[4.5rem] z-20 flex items-center justify-between px-6">
        <p className="eyebrow text-bone/60">The Marlowe way</p>
        <div className="flex items-center gap-3">
          <Counter value={active} />
          <span className="relative h-px w-10 bg-bone/15">
            <span className="ch-bar absolute inset-0 origin-left scale-x-0 bg-brass" />
          </span>
          <span className="num eyebrow text-bone/40">0{chapters.length}</span>
        </div>
      </div>

      {/* Copy slot */}
      <div className="absolute inset-x-0 bottom-0 z-20 px-6 pb-12">
        <div className="relative min-h-[15.5rem]">
          {chapters.map((c) => (
            <article key={c.n} className="ch-txt absolute inset-x-0 bottom-0">
              <p className="eyebrow text-brass">
                <span className="num">{c.n}</span>
                <span className="mx-2 text-bone/30">—</span>
                {c.title}
              </p>
              <h3 className="display mt-4 text-[2.25rem] text-bone">{c.heading}</h3>
              <p className="mt-4 max-w-[36ch] font-sans text-[14.5px] leading-[1.65] text-bone/65">
                {c.body}
              </p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

function Counter({ value }: { value: number }) {
  return (
    <span className="relative block h-[11px] w-[2em] overflow-hidden">
      {chapters.map((c, i) => (
        <span
          key={c.n}
          className={cn(
            "num eyebrow absolute inset-0 text-bone transition-all duration-500 ease-out",
            i === value
              ? "translate-y-0 opacity-100"
              : i < value
                ? "-translate-y-full opacity-0"
                : "translate-y-full opacity-0"
          )}
        >
          {c.n}
        </span>
      ))}
    </span>
  );
}

function StaticChapters() {
  return (
    <section id="story" className="bg-ink px-6 pb-16" aria-label="How a car reaches you">
      <div className="space-y-14">
        {chapters.map((c) => (
          <article key={c.n}>
            <div className="aspect-[4/5] overflow-hidden">
              <img className="h-full w-full object-cover" src={c.image} alt={c.alt} loading="lazy" />
            </div>
            <p className="eyebrow mt-6 text-brass">
              <span className="num">{c.n}</span>
              <span className="mx-2 text-bone/30">—</span>
              {c.title}
            </p>
            <h3 className="display mt-4 text-[2.25rem] text-bone">{c.heading}</h3>
            <p className="mt-4 font-sans text-[14.5px] leading-[1.65] text-bone/65">{c.body}</p>
          </article>
        ))}
      </div>
    </section>
  );
}
