import { useRef } from "react";
import { gsap, useGSAP } from "../lib/gsap";
import { images } from "../data/content";

export default function Hero() {
  const root = useRef<HTMLElement>(null);

  useGSAP(
    () => {
      // ---- Intro (runs once on load) -----------------------------------
      const intro = gsap.timeline({ defaults: { ease: "power3.out" } });
      intro
        .fromTo(
          ".hero-img",
          { scale: 1.18 },
          { scale: 1, duration: 2.4, ease: "power2.out" }
        )
        .to(".hero-veil", { autoAlpha: 0, duration: 1.4, ease: "power2.inOut" }, 0.1)
        .from(".hero-eyebrow", { y: 14, autoAlpha: 0, duration: 0.9 }, 0.8)
        .from(
          ".hero-line",
          { yPercent: 108, duration: 1.2, stagger: 0.14, ease: "power4.out" },
          0.95
        )
        .from(".hero-sub", { y: 14, autoAlpha: 0, duration: 0.9 }, 1.5)
        .from(".hero-cta", { y: 12, autoAlpha: 0, duration: 0.8, stagger: 0.1 }, 1.7)
        .from(".hero-scroll", { autoAlpha: 0, duration: 0.8 }, 2.2);

      // ---- Scroll story (gsap.com "Pin, Scrub" pattern) -----------------
      const mm = gsap.matchMedia();
      mm.add("(prefers-reduced-motion: no-preference)", () => {
        const tl = gsap.timeline({
          scrollTrigger: {
            trigger: root.current,
            start: "top top",
            end: "+=110%",
            pin: true,
            scrub: 1,
            anticipatePin: 1,
          },
        });

        tl.to(".hero-zoom", { scale: 1.16, yPercent: -4, ease: "none" }, 0)
          .to(".hero-copy", { yPercent: -18, autoAlpha: 0, ease: "none", duration: 0.5 }, 0)
          .to(".hero-scroll", { autoAlpha: 0, ease: "none", duration: 0.2 }, 0)
          .to(".hero-dim", { opacity: 0.62, ease: "none" }, 0)
          .fromTo(
            ".hero-second > *",
            { y: 28, autoAlpha: 0 },
            { y: 0, autoAlpha: 1, ease: "none", duration: 0.55, stagger: 0.08 },
            0.4
          );
      });
    },
    { scope: root }
  );

  return (
    <section
      id="top"
      ref={root}
      className="relative h-[100svh] min-h-[560px] overflow-hidden bg-ink"
      aria-label="Welcome to Marlowe Motor Company"
    >
      {/* Photography */}
      <div className="hero-zoom absolute inset-0 will-change-transform">
        <img
          className="hero-img h-full w-full object-cover object-[58%_center] will-change-transform"
          src={images.hero}
          alt="The front of a dark Aston Martin, low sunlight tracing its bonnet"
          fetchPriority="high"
          decoding="async"
        />
      </div>

      {/* Tonal grading */}
      <div className="pointer-events-none absolute inset-0 bg-gradient-to-b from-ink/55 via-transparent to-transparent" />
      <div className="pointer-events-none absolute inset-x-0 bottom-0 h-[62%] bg-gradient-to-t from-ink via-ink/70 to-transparent" />
      <div className="hero-dim pointer-events-none absolute inset-0 bg-ink opacity-0" />
      <div className="grain pointer-events-none absolute inset-0" />
      <div className="hero-veil pointer-events-none absolute inset-0 bg-ink" />

      {/* Headline */}
      <div className="hero-copy absolute inset-x-0 bottom-0 px-6 pb-[4.5rem]">
        <p className="hero-eyebrow eyebrow text-brass">
          Independent · Est. 1998 · Weybridge
        </p>

        <h1 className="display mt-5 text-[clamp(2.5rem,11.5vw,3.2rem)] text-bone">
          <span className="-mb-2 block overflow-hidden pb-2">
            <span className="hero-line block leading-[1.06] will-change-transform">
              Exceptional cars.
            </span>
          </span>
          <span className="-mb-2 block overflow-hidden pb-2">
            <span className="hero-line block font-light italic leading-[1.06] will-change-transform">
              No compromises.
            </span>
          </span>
        </h1>

        <p className="hero-sub mt-5 max-w-[32ch] font-sans text-[15px] leading-[1.6] text-bone/70">
          A family-run showroom with a curated collection of modern supercars, luxury SUVs and
          collector-grade classics.
        </p>

        <div className="mt-8 flex gap-3">
          <a
            href="#collection"
            className="hero-cta tap flex h-12 flex-1 items-center justify-center rounded-full bg-bone font-sans text-[11px] font-semibold uppercase tracking-[0.2em] text-ink"
          >
            View the collection
          </a>
          <a
            href="#visit"
            className="hero-cta tap flex h-12 flex-1 items-center justify-center rounded-full border border-bone/30 font-sans text-[11px] font-medium uppercase tracking-[0.2em] text-bone backdrop-blur-sm"
          >
            Book a viewing
          </a>
        </div>
      </div>

      {/* Second beat — revealed by scroll */}
      <div className="hero-second pointer-events-none absolute inset-x-0 bottom-0 px-6 pb-[5.5rem]">
        <p className="eyebrow text-brass opacity-0">Twenty-eight years in</p>
        <p className="display mt-5 text-[2.7rem] text-bone opacity-0">
          Every car here was <span className="italic font-light">chosen</span>, not stocked.
        </p>
        <p className="mt-5 max-w-[30ch] font-sans text-[15px] leading-[1.6] text-bone/65 opacity-0">
          Never more than thirty at a time. Each one driven, checked and prepared by the people who
          will hand you the keys.
        </p>
      </div>

      {/* Scroll cue */}
      <div className="hero-scroll pointer-events-none absolute bottom-5 right-6 flex items-center gap-3">
        <span className="eyebrow text-bone/50">Scroll</span>
        <span className="relative h-8 w-px overflow-hidden bg-bone/15">
          <span className="absolute inset-x-0 top-0 h-1/2 animate-[scrollcue_1.8s_ease-in-out_infinite] bg-bone/80" />
        </span>
      </div>

      <style>{`
        @keyframes scrollcue {
          0% { transform: translateY(-100%); }
          60%, 100% { transform: translateY(220%); }
        }
      `}</style>
    </section>
  );
}
