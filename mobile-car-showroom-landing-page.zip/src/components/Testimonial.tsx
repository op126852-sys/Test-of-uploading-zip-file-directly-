import { Star } from "lucide-react";
import Reveal from "./Reveal";

export default function Testimonial() {
  return (
    <section className="bg-ink-2 px-6 py-20" aria-label="Client testimonial">
      <Reveal>
        <p className="eyebrow text-brass">From our clients</p>
        <blockquote className="display mt-8 text-[2.1rem] leading-[1.2] text-bone">
          “They found the exact car I'd been after for two years — right colour, right spec — and it
          arrived better than described. That never happens.”
        </blockquote>
        <footer className="mt-9 flex items-end justify-between gap-6 border-t border-bone/10 pt-6">
          <div>
            <p className="font-sans text-[13.5px] font-medium text-bone">James Whitfield</p>
            <p className="mt-1 font-sans text-[12px] text-bone/50">
              Ferrari 458 Speciale · Guildford
            </p>
          </div>
          <div className="text-right">
            <div className="flex items-center justify-end gap-0.5 text-bone">
              {Array.from({ length: 5 }).map((_, i) => (
                <Star key={i} className="h-3 w-3 fill-current" strokeWidth={0} />
              ))}
            </div>
            <p className="num mt-1.5 font-sans text-[12px] text-bone/50">
              4.9 · 312 Google reviews
            </p>
          </div>
        </footer>
      </Reveal>
    </section>
  );
}
