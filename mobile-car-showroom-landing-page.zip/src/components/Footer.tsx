import { showroom } from "../data/content";

const cols = [
  ["Collection", "Sell your car", "Sourcing", "Finance"],
  ["Our story", "Visit", "Journal", "Contact"],
];

export default function Footer() {
  return (
    <footer className="border-t border-bone/10 bg-ink px-6 pt-14 pb-32 safe-bottom">
      <p className="display text-[3.6rem] leading-[0.9] text-bone">Marlowe</p>
      <p className="eyebrow mt-4 text-bone/40">Motor Company · Est. 1998</p>

      <div className="mt-10 grid grid-cols-2 gap-6">
        {cols.map((col, i) => (
          <ul key={i} className="space-y-3 font-sans text-[13.5px] text-bone/65">
            {col.map((l) => (
              <li key={l}>
                <a href="#top" className="tap">
                  {l}
                </a>
              </li>
            ))}
          </ul>
        ))}
      </div>

      <div className="mt-10 hairline" />

      <div className="mt-6 flex items-center justify-between font-sans text-[12px] text-bone/50">
        <a href={showroom.phoneHref}>{showroom.phone}</a>
        <a href="#top" className="eyebrow text-bone/50">
          Back to top
        </a>
      </div>

      <p className="mt-6 font-sans text-[11px] leading-[1.7] text-bone/35">
        Marlowe Motor Company Ltd is registered in England and Wales, company no. 03571120.
        Registered office: {showroom.address.join(", ")}. We are a credit broker, not a lender,
        authorised and regulated by the Financial Conduct Authority. Finance is subject to status
        and available to UK residents aged 18 and over. Vehicle images are of the actual cars unless
        stated. © 2026 Marlowe Motor Company.
      </p>
    </footer>
  );
}
