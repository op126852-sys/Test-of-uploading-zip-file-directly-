import { useRef } from "react";
import { Phone, MessageCircle, Navigation, ArrowUpRight } from "lucide-react";
import { gsap, useGSAP } from "../lib/gsap";
import { images, showroom } from "../data/content";
import Reveal from "./Reveal";

export default function Visit() {
  const root = useRef<HTMLElement>(null);

  // Gentle parallax on the showroom photograph
  useGSAP(
    () => {
      gsap.fromTo(
        ".visit-img",
        { yPercent: -8 },
        {
          yPercent: 8,
          ease: "none",
          scrollTrigger: {
            trigger: ".visit-frame",
            start: "top bottom",
            end: "bottom top",
            scrub: true,
          },
        }
      );
    },
    { scope: root }
  );

  const actions = [
    { label: "Call", href: showroom.phoneHref, Icon: Phone },
    { label: "WhatsApp", href: showroom.whatsapp, Icon: MessageCircle },
    { label: "Directions", href: showroom.mapsHref, Icon: Navigation },
  ];

  return (
    <section id="visit" ref={root} className="bg-ink" aria-label="Visit the showroom">
      <div className="visit-frame relative aspect-[4/5] overflow-hidden">
        <img
          className="visit-img h-[116%] w-full object-cover"
          src={images.showroom}
          alt="Cars displayed inside the Marlowe showroom"
          loading="lazy"
          decoding="async"
        />
        <div className="pointer-events-none absolute inset-x-0 bottom-0 h-3/4 bg-gradient-to-t from-ink via-ink/60 to-transparent" />
        <div className="absolute inset-x-0 bottom-0 px-6 pb-8">
          <Reveal>
            <p className="eyebrow text-brass">Visit</p>
            <h2 className="display mt-4 text-[2.6rem] text-bone">
              A short drive from <span className="italic font-light">Brooklands</span>.
            </h2>
          </Reveal>
        </div>
      </div>

      <div className="px-6 pt-8 pb-24">
        <Reveal className="grid grid-cols-2 gap-6 font-sans text-[13.5px] leading-[1.7] text-bone/75">
          <div>
            <p className="eyebrow mb-3 text-bone/40">Showroom</p>
            {showroom.address.map((line) => (
              <p key={line}>{line}</p>
            ))}
            <a href={showroom.phoneHref} className="mt-3 block text-bone">
              {showroom.phone}
            </a>
          </div>
          <div>
            <p className="eyebrow mb-3 text-bone/40">Hours</p>
            {showroom.hours.map(([d, h]) => (
              <div key={d} className="flex flex-col">
                <span className="text-bone/50">{d}</span>
                <span className="num text-bone">{h}</span>
              </div>
            ))}
          </div>
        </Reveal>

        <Reveal className="mt-10">
          <div className="grid grid-cols-3 gap-2">
            {actions.map(({ label, href, Icon }) => (
              <a
                key={label}
                href={href}
                target={href.startsWith("http") ? "_blank" : undefined}
                rel={href.startsWith("http") ? "noreferrer" : undefined}
                className="tap flex h-[4.5rem] flex-col items-center justify-center gap-2 border border-bone/12 text-bone active:bg-bone/5"
              >
                <Icon className="h-[18px] w-[18px]" strokeWidth={1.5} />
                <span className="eyebrow text-bone/70">{label}</span>
              </a>
            ))}
          </div>
          <a
            href={`mailto:${showroom.email}?subject=Private%20viewing`}
            className="tap mt-3 flex h-13 items-center justify-between rounded-full bg-bone px-6 font-sans text-[11px] font-semibold uppercase tracking-[0.2em] text-ink"
          >
            Book a private viewing
            <ArrowUpRight className="h-4 w-4" strokeWidth={1.75} />
          </a>
          <p className="mt-5 font-sans text-[12px] leading-relaxed text-bone/40">
            Viewings outside opening hours are welcome — just call ahead. Private parking on site.
          </p>
        </Reveal>
      </div>
    </section>
  );
}
