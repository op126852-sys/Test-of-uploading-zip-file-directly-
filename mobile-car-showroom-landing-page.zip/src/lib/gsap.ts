import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { useGSAP } from "@gsap/react";

// Register once, app-wide (see gsap.com/resources/React — protects against tree-shaking)
gsap.registerPlugin(ScrollTrigger, useGSAP);

// Mobile browsers resize the viewport when the address bar shows/hides.
// Ignoring those resizes stops pinned sections from jumping mid-scroll.
ScrollTrigger.config({ ignoreMobileResize: true });

gsap.defaults({ ease: "power3.out", duration: 1 });

export { gsap, ScrollTrigger, useGSAP };
