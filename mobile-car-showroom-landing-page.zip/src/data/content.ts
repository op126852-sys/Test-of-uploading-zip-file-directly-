const px = (id: number, w: number, h: number) =>
  `https://images.pexels.com/photos/${id}/pexels-photo-${id}.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=${w}&h=${h}`;

export const images = {
  hero: px(10982214, 1000, 1600),
  heroFallback: px(6952776, 1200, 800),
  showroom: px(16176576, 1000, 1400),
  chapters: {
    sourced: px(6952776, 1000, 1250),
    prepared: px(14231684, 1000, 1250),
    handover: px(31362321, 1000, 1250),
  },
};

export type Car = {
  id: string;
  year: number;
  make: string;
  model: string;
  variant?: string;
  colour: string;
  miles: number;
  gearbox: string;
  price: number;
  status?: "Just arrived" | "Reserved" | "Due in";
  image: string;
};

export const collection: Car[] = [
  {
    id: "gt3",
    year: 2022,
    make: "Porsche",
    model: "911 GT3",
    variant: "992 · PDK · Clubsport",
    colour: "Shark Blue",
    miles: 3400,
    gearbox: "PDK",
    price: 164950,
    status: "Just arrived",
    image: px(27505234, 1200, 900),
  },
  {
    id: "huracan",
    year: 2021,
    make: "Lamborghini",
    model: "Huracán EVO",
    variant: "RWD · Lifting system · Sensonum",
    colour: "Rosso Mars",
    miles: 6800,
    gearbox: "LDF",
    price: 179950,
    image: px(28559696, 1200, 900),
  },
  {
    id: "dbs",
    year: 2020,
    make: "Aston Martin",
    model: "DBS Superleggera Volante",
    variant: "5.2 V12 · Carbon exterior pack",
    colour: "Xenon Grey",
    miles: 9100,
    gearbox: "Auto",
    price: 172500,
    status: "Reserved",
    image: px(8376871, 1200, 900),
  },
  {
    id: "rr",
    year: 2023,
    make: "Range Rover",
    model: "P530 Autobiography LWB",
    variant: "7 seats · Rear executive class",
    colour: "Charente Grey",
    miles: 4200,
    gearbox: "Auto",
    price: 139950,
    image: px(31574920, 1200, 900),
  },
  {
    id: "488",
    year: 2019,
    make: "Ferrari",
    model: "488 Pista",
    variant: "Carbon wheels · Racing seats",
    colour: "Rosso Corsa",
    miles: 2100,
    gearbox: "F1 DCT",
    price: 289000,
    image: px(12506011, 1200, 900),
  },
  {
    id: "g50",
    year: 1988,
    make: "Porsche",
    model: "911 Carrera 3.2",
    variant: "G50 · Matching numbers",
    colour: "Guards Red",
    miles: 78000,
    gearbox: "Manual",
    price: 84950,
    status: "Due in",
    image: px(38234790, 1200, 900),
  },
];

export const chapters = [
  {
    n: "01",
    title: "Sourced",
    heading: "Found, not fetched.",
    body:
      "Most of our cars never reach the open market. They come from collectors we've known for years, from main-dealer relationships, and from clients who bought their last car here.",
    image: images.chapters.sourced,
    alt: "A dark Aston Martin with its doors open in a dimly lit private garage",
  },
  {
    n: "02",
    title: "Prepared",
    heading: "Forty hours before the first photograph.",
    body:
      "Every car receives a full history and provenance check, a fresh main-dealer service, and multi-stage paint correction in our own workshop. Then, and only then, it's photographed.",
    image: images.chapters.prepared,
    alt: "A detailer machine-polishing the paintwork of a black car",
  },
  {
    n: "03",
    title: "Handed over",
    heading: "No hurry. That's the point.",
    body:
      "Collect from the showroom with a coffee and a proper walk-round, or take covered delivery anywhere in the UK. Six months' warranty and our number, for whenever you need it.",
    image: images.chapters.handover,
    alt: "A silver sports car on a quiet countryside road in autumn",
  },
];

export const services = [
  {
    title: "Sell your car",
    body: "A firm offer within 24 hours. Funds cleared the same day we collect.",
  },
  {
    title: "Sourcing",
    body: "Tell us the spec, the colour, the mileage. We'll find it — quietly.",
  },
  {
    title: "Finance",
    body: "HP, PCP and lease purchase through a small panel of specialist lenders.",
  },
  {
    title: "Part exchange",
    body: "Bring anything. We'll value it honestly and take it on the day.",
  },
];

export const showroom = {
  name: "Marlowe Motor Company",
  short: "Marlowe",
  phone: "+44 (0)1932 856 120",
  phoneHref: "tel:+441932856120",
  whatsapp: "https://wa.me/441932856120",
  email: "sales@marlowemotor.co.uk",
  address: ["Unit 4, Brooklands Drive", "Weybridge, Surrey", "KT13 0SL"],
  mapsHref: "https://maps.google.com/?q=Brooklands+Drive+Weybridge+KT13+0SL",
  hours: [
    ["Monday – Friday", "9.00 – 18.00"],
    ["Saturday", "9.00 – 17.00"],
    ["Sunday", "By appointment"],
  ],
};

export const formatPrice = (n: number) =>
  "£" + n.toLocaleString("en-GB", { maximumFractionDigits: 0 });

export const formatMiles = (n: number) =>
  n.toLocaleString("en-GB", { maximumFractionDigits: 0 }) + " miles";
